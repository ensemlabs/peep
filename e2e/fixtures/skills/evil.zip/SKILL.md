---
name: evil-skill
description: zip-slip attempt
---

# evil
